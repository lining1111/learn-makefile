#include<stdio.h>
int main()
{
	printf("hello world!\n");
	printf("hello maekfile\n");
	return 0;

}
