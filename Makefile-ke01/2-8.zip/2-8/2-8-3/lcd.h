void lcd_init();
