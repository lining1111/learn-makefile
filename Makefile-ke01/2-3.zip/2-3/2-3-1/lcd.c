#include<stdio.h>
void lcd_init()
{
	printf("lcd_init...\n");
}
