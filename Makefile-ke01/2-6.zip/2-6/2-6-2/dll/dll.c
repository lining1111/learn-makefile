#include <stdio.h>

void dll_init()
{
	printf("dll_init ...\n");

}
