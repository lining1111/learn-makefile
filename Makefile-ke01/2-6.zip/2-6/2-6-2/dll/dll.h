#ifndef __DLL_H
#define __DLL_H
void dll_init();
#endif

